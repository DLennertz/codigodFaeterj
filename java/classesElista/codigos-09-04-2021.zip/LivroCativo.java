public class LivroCativo implements Emprestavel {

	public void emprestar(Usuario u) {
		System.out.println("LivroCativo não se empresta");
	}

}
