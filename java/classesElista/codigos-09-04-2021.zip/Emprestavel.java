public interface Emprestavel {
	
	public abstract void emprestar(Usuario u);	
	
}
