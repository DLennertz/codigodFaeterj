public class LivroEspecial extends Livro {

	public LivroEspecial() {
		super("livro especial");
	}

}
